# zabbix init
export PATH=$PATH:/usr/local/zabbix/bin:/usr/local/zabbix/sbin
